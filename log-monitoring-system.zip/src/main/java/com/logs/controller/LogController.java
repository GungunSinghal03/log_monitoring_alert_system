package com.logs.controller;

import com.logs.entity.Log;
import com.logs.service.LogService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/logs")
public class LogController {

private final LogService service;

public LogController(LogService service){
this.service = service;
}

@PostMapping
public Log ingest(@RequestBody Log log){
return service.save(log);
}

@GetMapping
public List<Log> getLogs(){
return service.getAll();
}
}
