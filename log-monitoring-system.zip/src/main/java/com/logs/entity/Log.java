package com.logs.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(indexes = {
@Index(name="idx_level", columnList="level"),
@Index(name="idx_timestamp", columnList="timestamp"),
@Index(name="idx_service", columnList="serviceName")
})
public class Log {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String message;
private String level;
private String serviceName;
private LocalDateTime timestamp;

// getters setters
}
