package com.logs.service.impl;

import com.logs.entity.Log;
import com.logs.repository.LogRepository;
import com.logs.service.LogService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LogServiceImpl implements LogService {

private final LogRepository repo;

public LogServiceImpl(LogRepository repo){
this.repo = repo;
}

public Log save(Log log){
return repo.save(log);
}

public List<Log> getAll(){
return repo.findAll();
}
}
