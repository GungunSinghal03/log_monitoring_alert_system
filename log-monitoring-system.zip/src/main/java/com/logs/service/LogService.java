package com.logs.service;

import com.logs.entity.Log;
import java.util.List;

public interface LogService {
Log save(Log log);
List<Log> getAll();
}
