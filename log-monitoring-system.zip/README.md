# Log Monitoring & Alert System (Spring Boot)

Run:
mvn spring-boot:run

Tech:
- Spring Boot
- MySQL
- JPA
